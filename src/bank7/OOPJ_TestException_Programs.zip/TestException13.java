package bank7;
//execute a try block normally
public class TestException13 {
	static void demo1() {
		try {
			System.out.println("Inside demo1() method");}
		finally {
			System.out.println("finally block");}}
	public static void main(String[] args) {
		demo1();}}
