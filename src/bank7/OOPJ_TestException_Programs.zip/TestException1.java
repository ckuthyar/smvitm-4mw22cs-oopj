package bank7;
public class TestException1 {
	public static void main(String[] args) {
		int amount=100;
		int qty=0;
		int rate=amount/qty;
		System.out.println(rate);}}
